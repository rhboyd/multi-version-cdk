"""
# Welcome to your CDK TypeScript Construct Library project!

You should explore the contents of this project. It demonstrates a CDK Construct Library that includes a construct (`MyApp`)
which contains an Amazon SQS queue that is subscribed to an Amazon SNS topic.

The construct defines an interface (`MyAppProps`) to configure the visibility timeout of the queue.

## Useful commands

* `npm run build`   compile typescript to js
* `npm run watch`   watch for changes and compile
* `npm run test`    perform the jest unit tests
"""
import abc
import builtins
import datetime
import enum
import typing

import jsii
import jsii.compat
import publication

import aws_cdk.aws_sns
import aws_cdk.aws_sns_subscriptions
import aws_cdk.aws_sqs
import aws_cdk.core

__jsii_assembly__ = jsii.JSIIAssembly.load("my_app", "0.1.0", __name__, "my_app@0.1.0.jsii.tgz")


class MyApp(aws_cdk.core.Construct, metaclass=jsii.JSIIMeta, jsii_type="my_app.MyApp"):
    def __init__(self, scope: aws_cdk.core.Construct, id: str, *, visibility_timeout: typing.Optional[aws_cdk.core.Duration]=None) -> None:
        """
        :param scope: -
        :param id: -
        :param visibility_timeout: The visibility timeout to be configured on the SQS Queue, in seconds. Default: Duration.seconds(300)
        """
        props = MyAppProps(visibility_timeout=visibility_timeout)

        jsii.create(MyApp, self, [scope, id, props])

    @builtins.property
    @jsii.member(jsii_name="queueArn")
    def queue_arn(self) -> str:
        """
        return
        :return: the ARN of the SQS queue
        """
        return jsii.get(self, "queueArn")


@jsii.data_type(jsii_type="my_app.MyAppProps", jsii_struct_bases=[], name_mapping={'visibility_timeout': 'visibilityTimeout'})
class MyAppProps():
    def __init__(self, *, visibility_timeout: typing.Optional[aws_cdk.core.Duration]=None):
        """
        :param visibility_timeout: The visibility timeout to be configured on the SQS Queue, in seconds. Default: Duration.seconds(300)
        """
        self._values = {
        }
        if visibility_timeout is not None: self._values["visibility_timeout"] = visibility_timeout

    @builtins.property
    def visibility_timeout(self) -> typing.Optional[aws_cdk.core.Duration]:
        """The visibility timeout to be configured on the SQS Queue, in seconds.

        default
        :default: Duration.seconds(300)
        """
        return self._values.get('visibility_timeout')

    def __eq__(self, rhs) -> bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs) -> bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return 'MyAppProps(%s)' % ', '.join(k + '=' + repr(v) for k, v in self._values.items())


__all__ = ["MyApp", "MyAppProps", "__jsii_assembly__"]

publication.publish()
